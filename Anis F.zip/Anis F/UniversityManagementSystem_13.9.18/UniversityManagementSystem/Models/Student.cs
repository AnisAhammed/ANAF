﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace UniversityManagementSystem.Models
{
    public class Student
    {
        public int StudentId { get; set; }
        
        [Display(Name = "Student Name")]
        [Required(ErrorMessage = "Please enter name")]
        public string StudentName { get; set; }

        [Display(Name = "Student Address")]
        [Required(ErrorMessage = "Please enter address")]
        public string StudentAddress { get; set; }

        [Remote("IsStudentEmailExist", "Validation", ErrorMessage = "Email already exist")]  
        [Display(Name = "Student Email")]
        [Required(ErrorMessage = "Please enter Email")]
        [RegularExpression(@"[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", ErrorMessage = "Please enter a valid email")]
        public string StudentEmail { get; set; }

        [Display(Name = "Student Contact No")]
        [Required(ErrorMessage = "Please enter Contact No")]
        [Phone(ErrorMessage ="enter valid phone number" )]
        //[StringLength(11, MinimumLength = 11, ErrorMessage = "Enter 11 numbers as contact No")]
        [RegularExpression(@"^(?:\+?88)?01[15-9]\d{8}$", ErrorMessage = "Please enter a valid contact No")]
        public string StudentContactNo { get; set; }
      
        public string RegNo { get; set; }

         [Display(Name = "Department")]
        [Required(ErrorMessage = "Please select department")]
        public int DeptId { get; set; }

         
        [Required(ErrorMessage = "Please select Date")]
        public DateTime Date { get; set; } 
    }
    }
