﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using UniversityManagementSystem.Gateway;
using UniversityManagementSystem.Models;

namespace UniversityManagementSystem.Manager
{
    public class ClassroomManager
    {
        ClassroomGateway classroomGateway = new ClassroomGateway();
        public String Save(Classroom classroom)
        {
            if (classroom.FromTime > classroom.ToTime)
            {
                return "To time can't less than From time )";
            }
            bool isTimeScheduleValid = IsTimeScheduleValid(classroom.RoomId, classroom.DayId, classroom.FromTime, classroom.ToTime);

            if (isTimeScheduleValid != true)
            {

                if (classroomGateway.Save(classroom) > 0)
                {
                    return "Saved Successfully !";
                }
                return "Failed to save";

            }
            return "Overlapping not allowed";
        }

        private bool IsTimeScheduleValid(int roomId, int dayId, DateTime startTime, DateTime endTime)
        {
            List<Classroom> schedule = classroomGateway.GetClassSchedulByStartAndEndingTime(roomId, dayId, startTime, endTime);
            foreach (var sd in schedule)
            {
                if ((sd.DayId == dayId && roomId == sd.RoomId) &&
                                 (startTime < sd.FromTime && endTime > sd.FromTime)
                                 || (startTime < sd.FromTime && endTime > sd.FromTime) ||
                                 (startTime == sd.FromTime) || (sd.FromTime < startTime && sd.ToTime > startTime)
                                 )
                {
                    return true;
                }

            }
            return false;

        }


        public string GetAllClassSchedulesByDeparmentId(int departmentId, int courseId)
        {
            List<TempClassSchedule> classSchedules = classroomGateway.GetAllClassSchedulesByDeparmentId(departmentId, courseId);

            string output = "";

            foreach (var acls in classSchedules)
            {

                if (acls.RoomNo.StartsWith("R"))
                {
                    output += acls.RoomNo + ", " + acls.DayName + ", " + acls.FromTime.ToShortTimeString() + " - " + acls.ToTime.ToShortTimeString() + ";<br />";
                }

                else if (acls.RoomNo.StartsWith("N"))
                {
                    output = acls.RoomNo;

                }

            }

            return output;
        }
    
    }
}