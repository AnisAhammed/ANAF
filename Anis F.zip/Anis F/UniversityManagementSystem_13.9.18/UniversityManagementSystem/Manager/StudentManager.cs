﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using UniversityManagementSystem.Gateway;
using UniversityManagementSystem.Models;

namespace UniversityManagementSystem.Manager
{
    public class StudentManager
    {
        StudentGateway aStudentGateway=new StudentGateway();
        DepartmentGateway aDepartmentGateway=new DepartmentGateway();

       public string Save(Student student)
       {
           string regNo = GetRegNo(student);
           int rowCount = aStudentGateway.Save(student, regNo);
           if (rowCount > 0)
           {
               return "Student information Saved";
           }
           return "Student information Not Saved";
       }


       public string GetRegNo(Student student)
       {
           Departments aDepartments = aDepartmentGateway.GetDeptById(student.DeptId);
           string departmentCode = aDepartments.DeptCode;
           int year = student.Date.Year;
           string strStudentNumber;


           int studentNumber = aStudentGateway.GetStudentNoByDeptAndYear(student.DeptId,year);

           studentNumber++;

          
           strStudentNumber = studentNumber.ToString("000");
           
          
           return departmentCode + "-" + year + "-" + strStudentNumber;


       }

       

        public bool DoesEmailExist(string email)
        {
            return aStudentGateway.DoesEmailExist(email);
        }
    }
    }
