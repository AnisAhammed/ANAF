﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using UniversityManagementSystem.Models;

namespace UniversityManagementSystem.Gateway
{
    public class StudentGateway:Gateway
    {
         public int Save(Student student, string regNo)  
        {
            
            Query = "INSERT INTO Student(StudentName,StudentAddress,StudentEmail, RegNo, StudentContactNo,DeptId,Date) " +
                    "VALUES(@StudentName,@StudentAddress,@StudentEmail, @regNo, @StudentContactNo,@DeptId,@Date)";
            Command = new SqlCommand(Query, Connection);
            Command.Parameters.AddWithValue("StudentName", student.StudentName);
            Command.Parameters.AddWithValue("StudentAddress", student.StudentAddress);
            Command.Parameters.AddWithValue("StudentEmail", student.StudentEmail);
            Command.Parameters.AddWithValue("regNo", regNo);
            Command.Parameters.AddWithValue("StudentContactNo", student.StudentContactNo);
            Command.Parameters.AddWithValue("DeptId", student.DeptId);
            Command.Parameters.AddWithValue("Date", student.Date);

            Connection.Open();
            int rowCount = Command.ExecuteNonQuery();
            Connection.Close();
            return rowCount;
        }

        public int GetStudentNoByDeptAndYear(int deptId,int year)
        {
            int StudentNumber = 0;

            Query = "SELECT COUNT(StudentId) AS StudentNumber FROM Student WHERE DeptId='" + deptId + "' AND Year(Date)='" + year + "'";
            
            Command = new SqlCommand(Query, Connection);
            
            Connection.Open();
            
            Reader = Command.ExecuteReader();

            if (Reader.HasRows)
            {
                Reader.Read();
                StudentNumber = (int)Reader["StudentNumber"];
            }

            Connection.Close();
            Reader.Close();

            return StudentNumber;
        }

        


        public bool DoesEmailExist(string email)
        {
            
            bool exist = false;

            Query = "SELECT * FROM Student WHERE StudentEmail='" + email + "'";

            Command = new SqlCommand(Query, Connection);

            Connection.Open();
            Reader = Command.ExecuteReader();

            if (Reader.HasRows)
            {
                exist = true;
            }
            Connection.Close();

            return exist;
        }
    }
    }
