﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using UniversityManagementSystem.Models;

namespace UniversityManagementSystem.Gateway
{
    public class CourseGateway:Gateway
    {
         public int Save(Course course) 
        {
            Query = "INSERT INTO Course(CourseCode,CourseName,Credit,Description,DeptId,SemisterId) VALUES(@CourseCode,@CourseName,@Credit,@Description,@DeptId,@SemisterId)";
            Command = new SqlCommand(Query, Connection);
            Command.Parameters.AddWithValue("CourseCode", course.CourseCode);
            Command.Parameters.AddWithValue("CourseName", course.CourseName);
            Command.Parameters.AddWithValue("Credit", course.Credit);
            Command.Parameters.AddWithValue("Description", course.Description);
            Command.Parameters.AddWithValue("DeptId", course.DeptId);
            Command.Parameters.AddWithValue("SemisterId", course.SemisterId);
          
            Connection.Open();
            int rowCount = Command.ExecuteNonQuery();
            Connection.Close();
            return rowCount;
        }

        public bool IsExitCode(string courseCode) 
        {
            Query = "SELECT * FROM Course WHERE CourseCode='" + courseCode + "'";
            Command = new SqlCommand(Query, Connection);
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                Connection.Close();
                return true;
            } Connection.Close();
            return false;
        }

        public bool IsExitName(string courseName) 
        {
            Query = "SELECT * FROM Course WHERE CourseName='" + courseName + "'";
            Command = new SqlCommand(Query, Connection);
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                Connection.Close();
                return true;
            } Connection.Close();
            return false;
        }
    }
    }
