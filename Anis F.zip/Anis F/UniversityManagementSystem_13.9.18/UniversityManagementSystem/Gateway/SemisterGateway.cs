﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using UniversityManagementSystem.Models;

namespace UniversityManagementSystem.Gateway
{
    public class SemisterGateway:Gateway
    {
        public List<Semister> GetAllSemister() 
        {
            Query = "Select * FROM Semister";
            Command = new SqlCommand(Query, Connection);
            Connection.Open();
            Reader = Command.ExecuteReader();
            List<Semister> semisterList = new List<Semister>(); 
            while (Reader.Read())
            {
                Semister semister = new Semister();
                semister.SemisterId = (int)Reader["SemisterId"];
                semister.SemisterName = Reader["SemisterName"].ToString();

                semisterList.Add(semister);
            }
            Reader.Close();
            Connection.Close();
            return semisterList;
        }
    }
}