﻿/// <reference path="jquery-ui-1.12.1.js" />
/// <reference path="jquery-1.12.4.js" />
/// <autosync enabled="true" />
/// <reference path="modernizr-2.6.2.js" />
/// <reference path="bootstrap.js" />
/// <reference path="respond.js" />
