﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using UniversityManagementSystem.Gateway;
using UniversityManagementSystem.Models;

namespace UniversityManagementSystem.Manager
{
    public class CourseManager
    {
        CourseGateway aCourseGateway=new CourseGateway();

        public bool IsExitCode(string courseCode) 
        {
            return aCourseGateway.IsExitCode(courseCode);
        }

        public List<Course> GetallCourses()
        {
            return aCourseGateway.GetallCourses();
        }

        public bool IsExitName(string courseName) 
        {
            return aCourseGateway.IsExitName(courseName);
        }
        public string Save(Course course)
        {
            if (IsExitCode(course.CourseCode))
            {
                return "Already This Code Exit!!!";
            }
            if ((course.CourseCode).Length>6)
            {
                return "please enter only 5 characters into code";
                
            }
            if (IsExitName(course.CourseName))
            {
                return "Already This Name Exit!!!";
            }
            int rowCount = aCourseGateway.Save(course);
            if (rowCount > 0)
            {
                return "Course Saved";
            }
            return "Course Not Saved";
        }
    }
}