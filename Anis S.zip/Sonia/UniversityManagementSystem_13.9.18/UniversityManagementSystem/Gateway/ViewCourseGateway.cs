﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using UniversityManagementSystem.Models;

namespace UniversityManagementSystem.Gateway
{
    public class ViewCourseGateway : Gateway
    {
        public List<ViewCourse> GetAllCoursesByDepartmentId(int departmentId)
        {
            Query = "Select * from ViewCourseInformation where DeptId = " + departmentId;
            Command = new SqlCommand(Query, Connection);
            Connection.Open();
            Reader = Command.ExecuteReader();
            List<ViewCourse> viewCourses = new List<ViewCourse>();
           
            while (Reader.Read())
            {
                ViewCourse aViewCourse = new ViewCourse();

                aViewCourse.CourseName = Reader["CourseName"].ToString();
                aViewCourse.CourseCode = Reader["CourseCode"].ToString();
                aViewCourse.CourseId = Convert.ToInt32(Reader["CourseId"]);
                aViewCourse.DeptId = Convert.ToInt32(Reader["DeptId"]);
                aViewCourse.SemisterId = Convert.ToInt32(Reader["SemisterId"]);
                aViewCourse.SemisterName = Reader["SemisterName"].ToString();
                aViewCourse.TeacherId = aViewCourse.TeacherId==null? Convert.ToInt32(Reader["TeacherId"]) : 0;

                var x = Reader["TeacherName"].ToString();
                if (Reader["TeacherName"].ToString() == "")
                {
                    x = "Not assigned yet";
                }
                aViewCourse.TeacherName = x;

                viewCourses.Add(aViewCourse);
            }
            Reader.Close();
            Connection.Close();
            return viewCourses;
        }
    }
}