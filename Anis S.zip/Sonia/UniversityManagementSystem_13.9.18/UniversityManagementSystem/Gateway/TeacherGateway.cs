﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using UniversityManagementSystem.Models;

namespace UniversityManagementSystem.Gateway
{
    public class TeacherGateway:Gateway
    {       
        public bool IsExit(string email)
        {
            Query = "SELECT * FROM Teacher WHERE TeacherEmail='" + email + "'";
            Command = new SqlCommand(Query, Connection);
            Connection.Open();
            Reader = Command.ExecuteReader();
            if (Reader.HasRows)
            {
                Connection.Close();
                return true;
            } Connection.Close();
            return false;
        }

        public int Save(Teacher aTeachers)
        {
            Query = "INSERT INTO Teacher(TeacherName,TeacherAddress,TeacherContact,TeacherEmail,DeptId,DesignationId,TakenCredit) VALUES(@name,@address,@contactNo,@email,@deptId,@desigId,@credit)";
            Command = new SqlCommand(Query, Connection);
            Command.Parameters.AddWithValue("name", aTeachers.TeacherName);
            Command.Parameters.AddWithValue("address", aTeachers.TeacherAddress);
            Command.Parameters.AddWithValue("contactNo", aTeachers.TeacherContact);
            Command.Parameters.AddWithValue("email", aTeachers.TeacherEmail);
            Command.Parameters.AddWithValue("deptId", aTeachers.DeptId);
            Command.Parameters.AddWithValue("desigId", aTeachers.DesignationId);
            Command.Parameters.AddWithValue("credit", aTeachers.TakenCredit);
            Connection.Open();
            int rowCount = Command.ExecuteNonQuery();
            Connection.Close();
            return rowCount;
        }

        public List<Teacher> GetAllTeachers()
        {
            Query = "Select * FROM Teacher";
            Command = new SqlCommand(Query, Connection);
            Connection.Open();
            Reader = Command.ExecuteReader();
            List<Teacher> teacherList = new List<Teacher>();
            while (Reader.Read())
            {
                Teacher teachers = new Teacher();
                teachers.TeacherId = (int)Reader["TeacherId"];
                teachers.TeacherName = Reader["TeacherName"].ToString();
                teachers.TeacherEmail = Reader["TeacherEmail"].ToString();
                teachers.TeacherContact = Reader["TeacherContact"].ToString();
                teachers.TeacherAddress = Reader["TeacherAddress"].ToString();
                teachers.DesignationId = Convert.ToInt32(Reader["DesignationId"].ToString());
                teachers.DeptId = Convert.ToInt32(Reader["DeptId"].ToString());
                teachers.TakenCredit = (decimal)Reader["TakenCredit"];

                teacherList.Add(teachers);
            }
            Reader.Close();
            Connection.Close();
            return teacherList;
        }
    }
}