﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

using UniversityManagementSystem.Models;

namespace UniversityManagementSystem.Gateway
{
    public class GradeGateway : Gateway
    {
        public List<Grade> GetAllGrade()
        {
            Query = "Select * FROM Grade";
            Command = new SqlCommand(Query, Connection);
            Connection.Open();
            Reader = Command.ExecuteReader();
            List<Grade> GradeList = new List<Grade>();
            while (Reader.Read())
            {
                Grade grades = new Grade();
                grades.GradeId = Convert.ToInt32(Reader["GradeId"]);
                grades.GradeLetter=Reader["GradeLetter"].ToString();
                GradeList.Add(grades);
            }
            Reader.Close();
            Connection.Close();
            return GradeList;
        }
    }
}