﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UniversityManagementSystem.Manager;

namespace UniversityManagementSystem.Controllers
{
    public class ValidationController : Controller
    {

        StudentManager aStudentManager = new StudentManager();

        [HttpGet]
        public JsonResult IsStudentEmailExist(string studentEmail)
        {

            bool isExist = aStudentManager.DoesEmailExist(studentEmail);

            return Json(!isExist, JsonRequestBehavior.AllowGet);
        }

	}
}