﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UniversityManagementSystem.Manager;
using UniversityManagementSystem.Models;

namespace UniversityManagementSystem.Controllers
{
    public class ViewCourseController : Controller
    {
        //
        // GET: /ViewCourse/
        ViewCourse aViewCourse = new ViewCourse();
        DepartmentManager aDepartmentManager = new DepartmentManager();
        ViewCourseManager aViewCourseManager = new ViewCourseManager();
        public ActionResult Index()
        {
            ViewBag.DepartmentList = aDepartmentManager.GetAllDepartments();
            return View();
        }

        [HttpPost]
        public ActionResult Index(int departmentId)
        {
            ViewBag.Departments = aDepartmentManager.GetAllDepartments();
            return View();
        }

        public JsonResult GetCourseInfoByDepartmentId(int departmentId)
        {
            var CourseInfo = aViewCourseManager.GetAllCoursesByDepartmentId(departmentId);
            var CourseList = CourseInfo.Where(a => a.DeptId == departmentId).ToList();
            return Json(CourseList);
        }
    }
}