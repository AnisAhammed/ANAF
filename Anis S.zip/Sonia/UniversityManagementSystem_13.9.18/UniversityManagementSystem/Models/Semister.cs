﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UniversityManagementSystem.Models
{
    public class Semister
    {
        public int SemisterId { get; set; }
        public string SemisterName { get; set; } 
    }
}