﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UniversityManagementSystem.Manager;

namespace UniversityManagementSystem.Controllers
{
    public class AssignCourseController : Controller
    {
        //
        // GET: /AssignCourse/

        DepartmentManager aDepartmentManager = new DepartmentManager();
        TeacherManager aTeacherManager = new TeacherManager();
        CourseManager aCourseManager = new CourseManager();
        public ActionResult AssignCourse()
        {
            ViewBag.DepartmentList = aDepartmentManager.GetAllDepartments();
            ViewBag.TeacherList = aTeacherManager.GetAllTeachers();
            ViewBag.CourseList = aCourseManager.GetallCourses();
            return View();
        }
	}
}