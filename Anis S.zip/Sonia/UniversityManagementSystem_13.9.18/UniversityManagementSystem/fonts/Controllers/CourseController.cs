﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UniversityManagementSystem.Manager;
using UniversityManagementSystem.Models;

namespace UniversityManagementSystem.Controllers
{
    
    public class CourseController : Controller
    {
        CourseManager aCourseManager=new CourseManager();
        DepartmentManager aDepartmentManager=new DepartmentManager();
        SemisterManager aSemisterManager=new SemisterManager();
        
        [HttpGet]
        public ActionResult CourseSave()
        {
            ViewBag.DepartmentList= aDepartmentManager.GetAllDepartments();
            ViewBag.SemisterList = aSemisterManager.GetAllSemister();
            return View();
        }

        [HttpPost]
        public ActionResult CourseSave(Course course)
        {
            ViewBag.DepartmentList = aDepartmentManager.GetAllDepartments();
            ViewBag.SemisterList = aSemisterManager.GetAllSemister();
            ViewBag.CourseList = aCourseManager.Save(course);
            return View();
        }
	}
}