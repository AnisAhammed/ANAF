﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace UniversityManagementSystem.Models
{
    public class ViewCourse
    {
      
        public string CourseCode { get; set; }
        public string CourseName { get; set; }
        public string SemisterName { get; set; }
        public int TeacherId { get; set; }
        public string TeacherName { get; set; }
        public int DepartmentId { get; set; }
        public int CourseId { get; set; }
        public int SemisterId { get; set; }

        public string Code { get; set; }
        public string Name { get; set; }
        public string Semester { get; set; }
        public string Teacher { get; set; }
    }
}