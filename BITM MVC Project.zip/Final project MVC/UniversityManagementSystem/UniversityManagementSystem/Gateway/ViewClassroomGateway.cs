﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using UniversityManagementSystem.Models;

namespace UniversityManagementSystem.Gateway
{
    public class ViewClassroomGateway : Gateway
    {

        public List<TempClassSchedule> GetAllClassSchedules()
        {
            List<TempClassSchedule> scheduleList = new List<TempClassSchedule>();
            Query = "SELECT * FROM ScheduleOfClass";
            Command = new SqlCommand(Query, Connection);
            Connection.Open();
            Reader = Command.ExecuteReader();
            while (Reader.Read())
            {
                TempClassSchedule schedule = new TempClassSchedule
                {
                    DepartmentId = Convert.ToInt32(Reader["DepartmentId"].ToString()),
                    CourseCode = Reader["CourseCode"].ToString(),
                    CourseName = Reader["CourseName"].ToString(),
                    RoomNo = Reader["Room_Name"].ToString(),
                    DayName = Reader["Day_Name"].ToString(),
                    StartTime = Convert.ToDateTime(Reader["StartTime"].ToString()),
                    EndTime = Convert.ToDateTime(Reader["EndTime"].ToString()),
                    Status = Convert.ToBoolean(Reader["AllocationStatus"])
                };
                scheduleList.Add(schedule);
            }
            Reader.Close();
            return scheduleList;
        }

        public List<Course> GetCourseByDepartmentId(int departmentId)
        {
            Query = "SELECT * FROM Course WHERE DepartmentId='" + departmentId + "'";
            Command = new SqlCommand(Query, Connection);
            Connection.Open();
            Reader = Command.ExecuteReader();
            List<Course> courses = new List<Course>();
            while (Reader.Read())
            {
                Course course = new Course();
                course.CourseId = Convert.ToInt32(Reader["CourseId"].ToString());
                course.CourseName = Reader["CourseName"].ToString();
                course.CourseCode = Reader["CourseCode"].ToString();
                course.CourseCredit = (decimal)Reader["CourseCredit"];
                course.DepartmentId = Convert.ToInt32(Reader["DepartmentId"].ToString());
                course.SemisterId = Convert.ToInt32(Reader["SemisterId"].ToString());
                courses.Add(course);
            }
            Reader.Close();
            Connection.Close();
            return courses;
        }

        public List<TempClassSchedule> GetAllClassSchedulesByDeparmentId(int departmentId, int courseId)
        {
            List<TempClassSchedule> scheduleList = new List<TempClassSchedule>();
            Query = "SELECT * FROM ScheduleOfClass WHERE DepartmentId='" + departmentId + "' AND CourseId='" + courseId + "' AND AllocationStatus='" + 1 + "'";
            Command = new SqlCommand(Query, Connection);
            Connection.Open();
            Reader = Command.ExecuteReader();
            while (Reader.Read())
            {
                TempClassSchedule schedule = new TempClassSchedule();

                schedule.DepartmentId = Convert.ToInt32(Reader["DepartmentId"].ToString());
                schedule.CourseCode = Reader["CourseCode"].ToString();
                schedule.CourseName = Reader["CourseName"].ToString();
                schedule.RoomNo = Reader["Room_Name"].ToString();
                schedule.DayName = Reader["Day_Name"].ToString();
                schedule.StartTime = Convert.ToDateTime(Reader["StartTime"].ToString());
                schedule.EndTime = Convert.ToDateTime(Reader["EndTime"].ToString());
                schedule.Status = Convert.ToBoolean(Reader["AllocationStatus"]);

                scheduleList.Add(schedule);
            }

            Reader.Close();
            Connection.Close();
            return scheduleList;
        }

    }
}