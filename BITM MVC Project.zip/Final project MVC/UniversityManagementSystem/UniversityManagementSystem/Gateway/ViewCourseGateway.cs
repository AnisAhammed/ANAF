﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using UniversityManagementSystem.Models;

namespace UniversityManagementSystem.Gateway
{
    public class ViewCourseGateway : Gateway
    {
        public List<ViewCourse> GetAllCoursesByDepartmentId(int departmentId)
        {
            Query = "Select * from ViewAssignCourse where DepartmentId = " + departmentId;
            Command = new SqlCommand(Query, Connection);
            Connection.Open();
            Reader = Command.ExecuteReader();
            List<ViewCourse> viewCourses = new List<ViewCourse>();
           
            while (Reader.Read())
            {
                ViewCourse aViewCourse = new ViewCourse();

                aViewCourse.Name = Reader["Name"].ToString();
                aViewCourse.Code = Reader["Code"].ToString();
                aViewCourse.DepartmentId = Convert.ToInt32(Reader["DepartmentId"]);
                aViewCourse.Semester = Reader["Semester"].ToString();
                aViewCourse.Teacher = Reader["Teacher"].ToString();                

                viewCourses.Add(aViewCourse);
            }
            Reader.Close();
            Connection.Close();
            return viewCourses;
        }
    }
}