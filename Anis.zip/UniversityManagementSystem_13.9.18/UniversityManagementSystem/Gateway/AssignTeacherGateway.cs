﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using UniversityManagementSystem.Manager;
using UniversityManagementSystem.Models;

namespace UniversityManagementSystem.Gateway
{
    public class AssignTeacherGateway : Gateway
    {
        TeacherManager aTeacherManager = new TeacherManager();        

        public int Save(AssignTeachers courseAssign)
        {
            Query = "INSERT INTO Assign(DeptId,TeacherId,CourseId,IsActive) VALUES(@deptId,@teacherId,@courseId,@status)";
            Command = new SqlCommand(Query, Connection);
            Command.Parameters.Clear();
            Command.Parameters.AddWithValue("@deptId", courseAssign.DeptId);
            Command.Parameters.AddWithValue("@teacherId", courseAssign.TeacherId);
            Command.Parameters.AddWithValue("@courseId", courseAssign.CourseId);
            Command.Parameters.AddWithValue("@status", 1);
            Connection.Open();
            int rowAffected = Command.ExecuteNonQuery();
            int updateResult = UpdateTeacher(courseAssign);
            Connection.Close();
            return rowAffected;

        }



        private int UpdateTeacher(AssignTeachers courseAssign)
        {
            Teacher teacher = aTeacherManager.GetAllTeachers().ToList().Find(t => t.TeacherId == courseAssign.TeacherId);

            double creditTakenbyTeacher = Convert.ToDouble(teacher.RemainingCredit) + Convert.ToDouble(courseAssign.Credit);
            Command.CommandText = "Update Teacher Set RemainingCredit='" + creditTakenbyTeacher + "' WHERE TeacherId='" +
                                     courseAssign.TeacherId + "'";
            return Command.ExecuteNonQuery();
        }

        public List<AssignTeachers> GetAllAssignTeachers()
        {
            Query = "SELECT * FROM Assign";
            Command = new SqlCommand(Query, Connection);
            List<AssignTeachers> assignList = new List<AssignTeachers>();
            Connection.Open();
            Reader = Command.ExecuteReader();
            while (Reader.Read())
            {
                AssignTeachers assignToTeacher = new AssignTeachers
                {
                    AssignId = Convert.ToInt32(Reader["AssignId"].ToString()),
                    DeptId = Convert.ToInt32(Reader["DeptId"].ToString()),
                    TeacherId = Convert.ToInt32(Reader["TeacherId"].ToString()),
                    CourseId = Convert.ToInt32(Reader["CourseId"].ToString()),
                    Status = Convert.ToBoolean(Reader["IsActive"].ToString())

                };
                assignList.Add(assignToTeacher);
            }
            Reader.Close();
            Connection.Close();
            return assignList;
        }

        public int Update(AssignTeachers courseAssign)
        {
            Query = "UPDATE Assign SET IsActive=1 WHERE TeacherId='" + courseAssign.TeacherId + "' AND CourseId='" + courseAssign.CourseId + "'";
            Command=new SqlCommand(Query,Connection);
            Connection.Open();
            Command.ExecuteNonQuery();
            int updateResult = UpdateTeacher(courseAssign);
            Connection.Close();
            return updateResult;
        }

    }
}