﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UniversityManagementSystem.Models
{
    public class Departments
    {
        public int DeptId { get; set; }
        public string DeptCode { get; set; }
        public string DeptName { get; set; }
    }
}