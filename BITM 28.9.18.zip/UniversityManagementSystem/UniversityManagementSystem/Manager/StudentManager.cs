﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using UniversityManagementSystem.Gateway;
using UniversityManagementSystem.Models;

namespace UniversityManagementSystem.Manager
{
    public class StudentManager
    {
        StudentGateway aStudentGateway = new StudentGateway();
        DepartmentGateway aDepartmentGateway = new DepartmentGateway();

        public List<Student> GetAllStudents()
        {
            return aStudentGateway.GetAllStudents();
        }

        public string Save(Student student)
        {
            string regNo = GetRegNo(student);
            int rowCount = aStudentGateway.Save(student, regNo);
            if (rowCount > 0)
            {
                Student info = aStudentGateway.GetStudentInfo(regNo);


                string msg = "Student information is Saved! ";
                msg += "<br/>";
                msg += "<br/>";
                msg += "Name:" + " " + info.Name + "<br/>" + "Email:" + " " + info.Email + "<br/>" + "Contact No:" + " " + info.ContactNo + "<br/>";
                msg += "Reg No:" + " " + info.RegNo + "<br/>" + "Date:" + " " + info.Date.ToString("MM/dd/yy") + "<br/>";
                msg += "Address:" + " " + info.Address + "<br/>" + "Department:" + info.DepartmentName;

                return msg;
            }
            return "Student information Not Saved";
        }


        public string GetRegNo(Student student)
        {
            Departments aDepartments = aDepartmentGateway.GetDeptById(student.DepartmentId);
            string departmentCode = aDepartments.DepartmentCode;
            int year = student.Date.Year;
            string strStudentNumber;


            int studentNumber = aStudentGateway.GetStudentNoByDeptAndYear(student.DepartmentId, year);

            studentNumber++;


            strStudentNumber = studentNumber.ToString("000");


            return departmentCode + "-" + year + "-" + strStudentNumber;

        }


        public bool DoesEmailExist(string email)
        {
            return aStudentGateway.DoesEmailExist(email);
        }
    }
}
