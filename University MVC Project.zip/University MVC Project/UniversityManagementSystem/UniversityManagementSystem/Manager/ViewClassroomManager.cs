﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using UniversityManagementSystem.Gateway;
using UniversityManagementSystem.Models;

namespace UniversityManagementSystem.Manager
{
    public class ViewClassroomManager
    {
        ViewClassroomGateway viewClassroomGateway=new ViewClassroomGateway();
        CourseGateway courseGateway=new CourseGateway();

        public List<TempClassSchedule> GetAllClassSchedules()
        {
            return viewClassroomGateway.GetAllClassSchedules();
        }

        public List<Course> GetCourseByDepartmentId(int departmentId)
        {
            return viewClassroomGateway.GetCourseByDepartmentId(departmentId);
        }

        public string GetAllClassSchedulesByDeparmentId(int departmentId, int courseId)
        {
            List<TempClassSchedule> classSchedules = viewClassroomGateway.GetAllClassSchedulesByDeparmentId(departmentId, courseId);

            string output = "";

            foreach (var aclass in classSchedules)
            {

                if (aclass.RoomNo.StartsWith("R"))
                {
                    output += aclass.RoomNo + ", " + aclass.DayName + ", " + aclass.StartTime.ToShortTimeString() + " - " + aclass.EndTime.ToShortTimeString() + ";<br />";
                }

                else if (aclass.RoomNo.StartsWith("N"))
                {
                    output = aclass.RoomNo;

                }

            }

            return output;
        }
    }
}