﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using UniversityManagementSystem.Models;

namespace UniversityManagementSystem.Gateway
{
    public class StudentGateway:Gateway
    {
        public List<Student> GetAllStudents()
        {
            Query = "SELECT * FROM Student";
            Command = new SqlCommand(Query, Connection);
            List<Student> students = new List<Student>();
            Connection.Open();
            SqlDataReader reader = Command.ExecuteReader();
            while (reader.Read())
            {
                Student student = new Student
                {
                    StudentId = Convert.ToInt32(reader["StudentId"].ToString()),
                    RegNo = reader["RegNo"].ToString(),
                    Name = reader["Name"].ToString(),
                    Email = reader["Email"].ToString(),
                    Address = reader["Address"].ToString(),
                    ContactNo = reader["ContactNo"].ToString(),
                    Date = Convert.ToDateTime(reader["Date"].ToString()),
                    DepartmentId = Convert.ToInt32(reader["DepartmentId"].ToString())
                };
                students.Add(student);
            }
            reader.Close();
            Connection.Close();
            return students;
        }

         public int Save(Student student, string regNo)  
        {
            
            Query = "INSERT INTO Student(Name,Address,Email, RegNo, ContactNo,DepartmentId,Date) " +
                    "VALUES(@Name,@Address,@Email, @regNo, @ContactNo,@DepartmentId,@Date)";
            Command = new SqlCommand(Query, Connection);
            Command.Parameters.AddWithValue("Name", student.Name);
            Command.Parameters.AddWithValue("Address", student.Address);
            Command.Parameters.AddWithValue("Email", student.Email);
            Command.Parameters.AddWithValue("regNo", regNo);
            Command.Parameters.AddWithValue("ContactNo", student.ContactNo);
            Command.Parameters.AddWithValue("DepartmentId", student.DepartmentId);
            Command.Parameters.AddWithValue("Date", student.Date);

            Connection.Open();
            int rowCount = Command.ExecuteNonQuery();
            Connection.Close();
            return rowCount;
        }

        public int GetStudentNoByDeptAndYear(int deptId,int year)
        {
            int StudentNumber = 0;

            Query = "SELECT COUNT(StudentId) AS StudentNumber FROM Student WHERE DepartmentId='" + deptId + "' AND Year(Date)='" + year + "'";
            
            Command = new SqlCommand(Query, Connection);
            
            Connection.Open();
            
            Reader = Command.ExecuteReader();

            if (Reader.HasRows)
            {
                Reader.Read();
                StudentNumber = (int)Reader["StudentNumber"];
            }

            Connection.Close();
            Reader.Close();

            return StudentNumber;
        }

        


        public bool DoesEmailExist(string email)
        {
            
            bool exist = false;

            Query = "SELECT * FROM Student WHERE Email='" + email + "'";

            Command = new SqlCommand(Query, Connection);

            Connection.Open();
            Reader = Command.ExecuteReader();

            if (Reader.HasRows)
            {
                exist = true;
            }
            Connection.Close();

            return exist;
        }

        public Student GetStudentInfo(string regNo)
        {
            Query = "SELECT Student.Address,Student.ContactNo,Student.StudentId,Student.Date,Student.Email,Student.Name,Student.RegNo,Department.DepartmentName FROM Student, Department WHERE RegNo='" + regNo + "'  AND Student.DepartmentId=Department.DepartmentId";



            //Query = "SELECT * FROM Student WHERE RegNo='" + regNo + "'";
            Command = new SqlCommand(Query, Connection);
            Connection.Open();
            Reader = Command.ExecuteReader();
            Student student = null;
            if (Reader.HasRows)
            {
                Reader.Read();
                student = new Student();
                student.Name = Reader["Name"].ToString();
                student.Address = Reader["Address"].ToString();
                student.RegNo = Reader["RegNo"].ToString();
                student.ContactNo = Reader["ContactNo"].ToString();
                student.Email = Reader["Email"].ToString();
                student.Date = (DateTime)Reader["Date"];
                student.DepartmentName = Reader["DepartmentName"].ToString();

            }
            Connection.Close();
            Reader.Close();

            return student;
        }
    }
    }
