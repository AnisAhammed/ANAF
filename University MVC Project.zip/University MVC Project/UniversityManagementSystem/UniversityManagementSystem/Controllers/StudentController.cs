﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UniversityManagementSystem.Manager;
using UniversityManagementSystem.Models;

namespace UniversityManagementSystem.Controllers
{
    public class StudentController : Controller
    {
        
        DepartmentManager aDepartmentManager=new DepartmentManager();
        StudentManager aStudentManager=new StudentManager();
        public ActionResult Register()
        {
            ViewBag.departmentList = aDepartmentManager.GetAllDepartments();
          

            return View();
        }

       
        
        [HttpPost]
        public ActionResult Register(Student student) 
        {
           

            ViewBag.Message = aStudentManager.Save(student);
            ViewBag.departmentList = aDepartmentManager.GetAllDepartments();
            ModelState.Clear();
            

            

            return View();
        }


       
       
	}
	}
