﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using UniversityManagementSystem.Models;

namespace UniversityManagementSystem.Gateway
{
    public class StudentGateway:Gateway
    {
         public int Save(Student student, string regNo)  
        {
            
            Query = "INSERT INTO Student(Name,Address,Email, RegNo, ContactNo,DepartmentId,Date) " +
                    "VALUES(@Name,@Address,@Email, @regNo, @ContactNo,@DepartmentId,@Date)";
            Command = new SqlCommand(Query, Connection);
            Command.Parameters.AddWithValue("Name", student.Name);
            Command.Parameters.AddWithValue("Address", student.Address);
            Command.Parameters.AddWithValue("Email", student.Email);
            Command.Parameters.AddWithValue("regNo", regNo);
            Command.Parameters.AddWithValue("ContactNo", student.ContactNo);
            Command.Parameters.AddWithValue("DepartmentId", student.DepartmentId);
            Command.Parameters.AddWithValue("Date", student.Date);

            Connection.Open();
            int rowCount = Command.ExecuteNonQuery();
            Connection.Close();
            return rowCount;
        }

        public int GetStudentNoByDeptAndYear(int deptId,int year)
        {
            int StudentNumber = 0;

            Query = "SELECT COUNT(StudentId) AS StudentNumber FROM Student WHERE DepartmentId='" + deptId + "' AND Year(Date)='" + year + "'";
            
            Command = new SqlCommand(Query, Connection);
            
            Connection.Open();
            
            Reader = Command.ExecuteReader();

            if (Reader.HasRows)
            {
                Reader.Read();
                StudentNumber = (int)Reader["StudentNumber"];
            }

            Connection.Close();
            Reader.Close();

            return StudentNumber;
        }

        


        public bool DoesEmailExist(string email)
        {
            
            bool exist = false;

            Query = "SELECT * FROM Student WHERE Email='" + email + "'";

            Command = new SqlCommand(Query, Connection);

            Connection.Open();
            Reader = Command.ExecuteReader();

            if (Reader.HasRows)
            {
                exist = true;
            }
            Connection.Close();

            return exist;
        }
    }
    }
